package com.makhzani.app

import android.app.Application
import android.content.Context
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.makhzani.app.data.AppDatabase
import com.makhzani.app.data.BackupManager
import com.makhzani.app.data.Item
import com.makhzani.app.data.MoveOutcome
import com.makhzani.app.data.MoveType
import com.makhzani.app.data.StockRepository
import com.makhzani.app.data.Units
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val app: Application = application
    private val repo = StockRepository(AppDatabase.get(application))

    val items: StateFlow<List<Item>> =
        repo.items.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val movements: StateFlow<List<com.makhzani.app.data.Movement>> =
        repo.movements.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    private val _messages = MutableSharedFlow<String>(extraBufferCapacity = 16)
    val messages: SharedFlow<String> = _messages.asSharedFlow()

    private fun say(text: String) {
        _messages.tryEmit(text)
    }

    init {
        viewModelScope.launch { seedIfNeeded() }
    }

    /** المواد الافتراضية — تُضاف مرة واحدة فقط عند أول تشغيل */
    private suspend fun seedIfNeeded() {
        val prefs = app.getSharedPreferences("makhzani", Context.MODE_PRIVATE)
        if (prefs.getBoolean("seeded", false)) return
        if (repo.getItems().isEmpty()) {
            repo.addItem("الحليب", Units.KG, 1, 0.0, 2.0)
            repo.addItem("المبيّض", Units.KG, 1, 0.0, 1.0)
            repo.addItem("الميلو", Units.KG, 1, 0.0, 1.0)
            repo.addItem("الكابتشينو", Units.KG, 1, 0.0, 1.0)
            repo.addItem("الكاسات", Units.PIECE, 1, 0.0, 100.0)
            repo.addItem("الملاعق", Units.PIECE, 1, 0.0, 100.0)
            repo.addItem("الإندومي", Units.PACK, 48, 0.0, 48.0)
        }
        prefs.edit().putBoolean("seeded", true).apply()
    }

    /** الكميات بالوحدة الأساسية (كغ أو قطعة) */
    fun addItem(name: String, unit: String, packSize: Int, qtyBase: Double, minBase: Double) {
        viewModelScope.launch {
            repo.addItem(name, unit, packSize, qtyBase, minBase)
            say("تمت إضافة «${name.trim()}» ✅")
        }
    }

    fun editItem(id: Long, name: String, minBase: Double) {
        viewModelScope.launch {
            repo.updateItem(id, name, minBase)
            say("تم حفظ التعديل ✅")
        }
    }

    fun deleteItem(item: Item) {
        viewModelScope.launch {
            repo.deleteItem(item.id)
            say("تم حذف «${item.name}»")
        }
    }

    fun move(item: Item, type: String, amountBase: Double, note: String) {
        viewModelScope.launch {
            when (val r = repo.move(item.id, type, amountBase, note)) {
                is MoveOutcome.Fail -> say(r.message)
                is MoveOutcome.Ok -> {
                    say(if (type == MoveType.IN) "تمت الإضافة ✅" else "تم السحب ✅")
                    if (type == MoveType.OUT && r.isLow) {
                        Notifier.notifyLow(app, r.item)
                    }
                }
            }
        }
    }

    fun backupTo(uri: Uri) {
        viewModelScope.launch {
            try {
                withContext(Dispatchers.IO) {
                    val json = BackupManager.toJson(repo.getItems(), repo.getMovements())
                    val out = app.contentResolver.openOutputStream(uri, "wt")
                        ?: throw IllegalStateException("تعذر فتح الملف")
                    out.use { it.write(json.toByteArray(Charsets.UTF_8)) }
                }
                say("تم حفظ النسخة الاحتياطية ✅")
            } catch (e: Exception) {
                say("تعذّر حفظ النسخة الاحتياطية")
            }
        }
    }

    fun restoreFrom(uri: Uri) {
        viewModelScope.launch {
            try {
                val parsed = withContext(Dispatchers.IO) {
                    val input = app.contentResolver.openInputStream(uri)
                        ?: throw IllegalStateException("تعذر فتح الملف")
                    val text = input.use { String(it.readBytes(), Charsets.UTF_8) }
                    BackupManager.fromJson(text)
                }
                repo.replaceAll(parsed.first, parsed.second)
                say("تمت الاستعادة: ${parsed.first.size} مادة و ${parsed.second.size} حركة ✅")
            } catch (e: Exception) {
                say("الملف غير صالح — لم يتغير أي شيء")
            }
        }
    }
}
