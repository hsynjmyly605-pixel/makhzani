package com.makhzani.app

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.makhzani.app.data.Item

object Notifier {
    private const val CHANNEL = "low_stock"

    fun ensureChannel(ctx: Context) {
        val channel = NotificationChannel(CHANNEL, "تنبيهات انخفاض المخزون", NotificationManager.IMPORTANCE_HIGH)
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(channel)
    }

    fun notifyLow(ctx: Context, item: Item) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) return

        val intent = Intent(ctx, MainActivity::class.java)
        val pi = PendingIntent.getActivity(
            ctx, 0, intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val text = if (item.quantity <= 0.0) "«${item.name}» نفد من المخزون"
        else "«${item.name}» منخفض: المتبقي ${item.qtyText()}"

        val n = NotificationCompat.Builder(ctx, CHANNEL)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("مخزني ☕ — تنبيه مخزون")
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setContentIntent(pi)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()
        NotificationManagerCompat.from(ctx).notify(item.id.toInt(), n)
    }
}
