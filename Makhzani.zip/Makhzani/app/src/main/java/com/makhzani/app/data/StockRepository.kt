package com.makhzani.app.data

import androidx.room.withTransaction
import kotlinx.coroutines.flow.Flow

sealed class MoveOutcome {
    data class Ok(val item: Item, val isLow: Boolean) : MoveOutcome()
    data class Fail(val message: String) : MoveOutcome()
}

class StockRepository(private val db: AppDatabase) {
    private val dao = db.dao()

    val items: Flow<List<Item>> = dao.observeItems()
    val movements: Flow<List<Movement>> = dao.observeMovements()

    suspend fun getItems(): List<Item> = dao.getItems()
    suspend fun getMovements(): List<Movement> = dao.getMovements()

    /** الكميات هنا بالوحدة الأساسية (كغ أو قطعة) */
    suspend fun addItem(name: String, unit: String, packSize: Int, initialQty: Double, minQty: Double) {
        db.withTransaction {
            val size = if (unit == Units.PACK) maxOf(packSize, 1) else 1
            val clean = name.trim()
            val qty = round3(initialQty)
            val id = dao.insertItem(
                Item(
                    name = clean,
                    unit = unit,
                    packSize = size,
                    quantity = qty,
                    minQuantity = round3(minQty),
                )
            )
            if (qty > 0) {
                dao.insertMovement(
                    Movement(
                        itemId = id,
                        itemName = clean,
                        unit = unit,
                        packSize = size,
                        type = MoveType.IN,
                        amount = qty,
                        balanceAfter = qty,
                        timestamp = System.currentTimeMillis(),
                        note = "رصيد افتتاحي",
                    )
                )
            }
        }
    }

    suspend fun updateItem(id: Long, name: String, minQty: Double) {
        db.withTransaction {
            val old = dao.getItem(id)
            if (old != null) {
                val clean = name.trim()
                dao.updateItem(old.copy(name = clean, minQuantity = round3(minQty)))
                dao.renameInMovements(id, clean)
            }
        }
    }

    suspend fun deleteItem(id: Long) {
        dao.deleteItem(id)
    }

    suspend fun move(itemId: Long, type: String, amount: Double, note: String): MoveOutcome {
        return db.withTransaction {
            val item = dao.getItem(itemId)
            val amt = round3(amount)
            if (item == null) {
                MoveOutcome.Fail("المادة غير موجودة")
            } else if (amt <= 0.0) {
                MoveOutcome.Fail("أدخل كمية صحيحة")
            } else {
                val newQty = if (type == MoveType.IN) round3(item.quantity + amt) else round3(item.quantity - amt)
                if (newQty < 0.0) {
                    MoveOutcome.Fail("الكمية المتوفرة غير كافية")
                } else {
                    val updated = item.copy(quantity = newQty)
                    dao.updateItem(updated)
                    dao.insertMovement(
                        Movement(
                            itemId = item.id,
                            itemName = item.name,
                            unit = item.unit,
                            packSize = item.packSize,
                            type = type,
                            amount = amt,
                            balanceAfter = newQty,
                            timestamp = System.currentTimeMillis(),
                            note = note,
                        )
                    )
                    MoveOutcome.Ok(updated, updated.quantity <= updated.minQuantity)
                }
            }
        }
    }

    suspend fun replaceAll(items: List<Item>, moves: List<Movement>) {
        db.withTransaction {
            dao.clearMovements()
            dao.clearItems()
            dao.insertItems(items)
            dao.insertMovements(moves)
        }
    }
}
