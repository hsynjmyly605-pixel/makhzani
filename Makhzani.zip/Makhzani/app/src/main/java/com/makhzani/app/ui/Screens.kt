@file:OptIn(ExperimentalMaterial3Api::class)

package com.makhzani.app.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.makhzani.app.MainViewModel
import com.makhzani.app.data.Item
import com.makhzani.app.data.Movement
import com.makhzani.app.data.MoveType
import com.makhzani.app.data.Units
import com.makhzani.app.fmtDate
import com.makhzani.app.fmtQty
import com.makhzani.app.isLow
import com.makhzani.app.qtyText
import com.makhzani.app.unitName
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun MakhzaniApp(vm: MainViewModel = viewModel()) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val snackbar = remember { SnackbarHostState() }

    LaunchedEffect(Unit) {
        vm.messages.collect { snackbar.showSnackbar(it) }
    }

    val tabs = listOf("المخزون" to "📦", "السجل" to "🕘", "النسخ الاحتياطي" to "💾")

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text("مخزني ☕", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = GreenPrimary,
                    titleContentColor = Color.White,
                ),
            )
        },
        bottomBar = {
            NavigationBar(containerColor = Color.White) {
                tabs.forEachIndexed { index, pair ->
                    NavigationBarItem(
                        selected = tab == index,
                        onClick = { tab = index },
                        icon = { Text(pair.second, fontSize = 20.sp) },
                        label = { Text(pair.first, fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            indicatorColor = GreenMid,
                            selectedTextColor = GreenDark,
                        ),
                    )
                }
            }
        },
        snackbarHost = { SnackbarHost(snackbar) },
    ) { padding ->
        Box(Modifier.padding(padding).fillMaxSize()) {
            when (tab) {
                0 -> StockScreen(vm)
                1 -> HistoryScreen(vm)
                else -> BackupScreen(vm)
            }
        }
    }
}

// ───────────────────────── المخزون ─────────────────────────

private data class Status(val label: String, val bg: Color, val fg: Color)

private fun statusOf(item: Item): Status = when {
    item.quantity <= 0.0 -> Status("نفد", Color(0xFFFFEBEE), Color(0xFFC62828))
    item.isLow() -> Status("منخفض", Color(0xFFFFF3E0), Color(0xFFE65100))
    else -> Status("متوفر", GreenLight, GreenPrimary)
}

@Composable
fun StockScreen(vm: MainViewModel) {
    val itemList by vm.items.collectAsStateWithLifecycle()

    var showAdd by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Item?>(null) }
    var deleting by remember { mutableStateOf<Item?>(null) }
    var moving by remember { mutableStateOf<Pair<Item, String>?>(null) }

    Box(Modifier.fillMaxSize().background(ScreenBg)) {
        if (itemList.isEmpty()) {
            Text(
                "لا توجد مواد بعد.\nاضغط «＋ مادة جديدة» للبدء.",
                modifier = Modifier.align(Alignment.Center).padding(24.dp),
                textAlign = TextAlign.Center,
                color = Color.Gray,
            )
        }
        LazyColumn(
            contentPadding = PaddingValues(12.dp, 12.dp, 12.dp, 96.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            val low = itemList.filter { it.isLow() }
            if (low.isNotEmpty()) {
                item(key = "low-banner") { LowBanner(low) }
            }
            items(itemList, key = { it.id }) { item ->
                ItemCard(
                    item = item,
                    onIn = { moving = Pair(item, MoveType.IN) },
                    onOut = { moving = Pair(item, MoveType.OUT) },
                    onEdit = { editing = item },
                    onDelete = { deleting = item },
                )
            }
        }
        ExtendedFloatingActionButton(
            onClick = { showAdd = true },
            modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp),
            containerColor = GreenPrimary,
            contentColor = Color.White,
        ) {
            Text("＋ مادة جديدة", fontWeight = FontWeight.Bold)
        }
    }

    if (showAdd) {
        ItemDialog(
            existing = null,
            onDismiss = { showAdd = false },
            onSave = { name, unit, packSize, qty, min ->
                val mult = if (unit == Units.PACK) packSize else 1
                vm.addItem(name, unit, packSize, qty * mult, min * mult)
                showAdd = false
            },
        )
    }

    editing?.let { item ->
        ItemDialog(
            existing = item,
            onDismiss = { editing = null },
            onSave = { name, unit, packSize, _, min ->
                val mult = if (unit == Units.PACK) packSize else 1
                vm.editItem(item.id, name, min * mult)
                editing = null
            },
        )
    }

    moving?.let { pair ->
        MoveDialog(
            item = pair.first,
            type = pair.second,
            onDismiss = { moving = null },
            onConfirm = { amountBase, note ->
                vm.move(pair.first, pair.second, amountBase, note)
                moving = null
            },
        )
    }

    deleting?.let { item ->
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text("حذف المادة") },
            text = { Text("هل تريد حذف «${item.name}» من المخزون؟ (سجل الحركات القديم يبقى محفوظاً)") },
            confirmButton = {
                TextButton(onClick = {
                    vm.deleteItem(item)
                    deleting = null
                }) { Text("حذف", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(onClick = { deleting = null }) { Text("إلغاء") } },
        )
    }
}

@Composable
private fun LowBanner(low: List<Item>) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF3E0)),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(Modifier.padding(14.dp)) {
            Text("⚠️ تنبيه: مخزون منخفض", fontWeight = FontWeight.Bold, color = Color(0xFFE65100))
            Spacer(Modifier.height(4.dp))
            Text(low.joinToString("، ") { it.name }, color = Color(0xFF5D4037))
        }
    }
}

@Composable
private fun ItemCard(
    item: Item,
    onIn: () -> Unit,
    onOut: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
) {
    val status = statusOf(item)
    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    item.name,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f),
                )
                Surface(shape = RoundedCornerShape(50), color = status.bg) {
                    Text(
                        status.label,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
                        color = status.fg,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                    )
                }
            }
            Spacer(Modifier.height(6.dp))
            Text(item.qtyText(), fontSize = 21.sp, fontWeight = FontWeight.Bold, color = status.fg)
            val unitLine = if (item.unit == Units.PACK)
                "الوحدة: ${unitName(item.unit)} — الطرد الواحد ${item.packSize} قطعة"
            else "الوحدة: ${unitName(item.unit)}"
            Text(unitLine, fontSize = 12.sp, color = Color.Gray)
            Text(
                "حد التنبيه: ${fmtQty(item.unit, item.packSize, item.minQuantity)}",
                fontSize = 12.sp,
                color = Color.Gray,
            )
            Spacer(Modifier.height(8.dp))
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Button(onClick = onIn, modifier = Modifier.weight(1f)) { Text("＋ إضافة") }
                OutlinedButton(onClick = onOut, modifier = Modifier.weight(1f)) { Text("－ سحب") }
                TextButton(onClick = onEdit) { Text("✏️") }
                TextButton(onClick = onDelete) { Text("🗑️") }
            }
        }
    }
}

// ───────────────────────── السجل ─────────────────────────

@Composable
fun HistoryScreen(vm: MainViewModel) {
    val list by vm.movements.collectAsStateWithLifecycle()
    Box(Modifier.fillMaxSize().background(ScreenBg)) {
        if (list.isEmpty()) {
            Text(
                "لا توجد حركات بعد.",
                modifier = Modifier.align(Alignment.Center),
                color = Color.Gray,
            )
        } else {
            LazyColumn(
                contentPadding = PaddingValues(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                items(list, key = { it.id }) { m -> MovementRow(m) }
            }
        }
    }
}

@Composable
private fun MovementRow(m: Movement) {
    val isIn = m.type == MoveType.IN
    val color = if (isIn) GreenPrimary else Color(0xFFC62828)
    val bg = if (isIn) GreenLight else Color(0xFFFFEBEE)
    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Surface(shape = RoundedCornerShape(12.dp), color = bg) {
                Text(
                    if (isIn) "＋" else "－",
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                    color = color,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                )
            }
            Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                Text(m.itemName, fontWeight = FontWeight.Bold)
                Text(
                    (if (isIn) "إضافة: " else "سحب: ") + fmtQty(m.unit, m.packSize, m.amount),
                    color = color,
                    fontSize = 14.sp,
                )
                Text(
                    "الرصيد بعد العملية: " + fmtQty(m.unit, m.packSize, m.balanceAfter),
                    fontSize = 12.sp,
                    color = Color.Gray,
                )
                if (m.note.isNotBlank()) {
                    Text("📝 " + m.note, fontSize = 12.sp, color = Color.Gray)
                }
                Text(fmtDate(m.timestamp), fontSize = 12.sp, color = Color.Gray)
            }
        }
    }
}

// ───────────────────────── النسخ الاحتياطي ─────────────────────────

@Composable
fun BackupScreen(vm: MainViewModel) {
    var pending by remember { mutableStateOf<Uri?>(null) }

    val createLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri -> if (uri != null) vm.backupTo(uri) }

    val openLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri -> if (uri != null) pending = uri }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ScreenBg)
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth(),
        ) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("النسخ الاحتياطي", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text("بياناتك تُحفظ تلقائياً على هاتفك. ومع ذلك ننصح بعمل نسخة احتياطية بين فترة وأخرى، وإرسالها لنفسك على واتساب أو حفظها في Google Drive.")
            }
        }
        Button(
            onClick = {
                val stamp = SimpleDateFormat("yyyyMMdd-HHmm", Locale.US).format(Date())
                createLauncher.launch("makhzani-$stamp.json")
            },
            modifier = Modifier.fillMaxWidth().height(52.dp),
        ) { Text("💾 إنشاء نسخة احتياطية", fontSize = 16.sp) }

        OutlinedButton(
            onClick = { openLauncher.launch(arrayOf("*/*")) },
            modifier = Modifier.fillMaxWidth().height(52.dp),
        ) { Text("♻️ استعادة من نسخة احتياطية", fontSize = 16.sp) }

        Text(
            "تنبيه: الاستعادة تستبدل كل المواد والسجل الحاليين بمحتوى الملف.",
            fontSize = 12.sp,
            color = Color.Gray,
        )
    }

    pending?.let { uri ->
        AlertDialog(
            onDismissRequest = { pending = null },
            title = { Text("استعادة البيانات") },
            text = { Text("ستُستبدل كل البيانات الحالية بمحتوى النسخة الاحتياطية. هل أنت متأكد؟") },
            confirmButton = {
                TextButton(onClick = {
                    vm.restoreFrom(uri)
                    pending = null
                }) { Text("نعم، استعد") }
            },
            dismissButton = { TextButton(onClick = { pending = null }) { Text("إلغاء") } },
        )
    }
}
