package com.makhzani.app.data

import org.json.JSONArray
import org.json.JSONObject

object BackupManager {

    fun toJson(items: List<Item>, moves: List<Movement>): String {
        val root = JSONObject()
        root.put("app", "makhzani")
        root.put("version", 1)
        root.put("createdAt", System.currentTimeMillis())

        val itemsArr = JSONArray()
        for (it in items) {
            val o = JSONObject()
            o.put("id", it.id)
            o.put("name", it.name)
            o.put("unit", it.unit)
            o.put("packSize", it.packSize)
            o.put("quantity", it.quantity)
            o.put("minQuantity", it.minQuantity)
            itemsArr.put(o)
        }
        root.put("items", itemsArr)

        val movesArr = JSONArray()
        for (m in moves) {
            val o = JSONObject()
            o.put("id", m.id)
            o.put("itemId", m.itemId)
            o.put("itemName", m.itemName)
            o.put("unit", m.unit)
            o.put("packSize", m.packSize)
            o.put("type", m.type)
            o.put("amount", m.amount)
            o.put("balanceAfter", m.balanceAfter)
            o.put("timestamp", m.timestamp)
            o.put("note", m.note)
            movesArr.put(o)
        }
        root.put("movements", movesArr)
        return root.toString(2)
    }

    /** يرمي استثناء إذا كان الملف غير صالح — قبل أن يُمسّ أي شيء في قاعدة البيانات */
    fun fromJson(text: String): Pair<List<Item>, List<Movement>> {
        val root = JSONObject(text)
        require(root.optString("app") == "makhzani") { "ملف غير صالح" }

        val validUnits = setOf(Units.KG, Units.PIECE, Units.PACK)
        val items = ArrayList<Item>()
        val itemsArr = root.getJSONArray("items")
        for (i in 0 until itemsArr.length()) {
            val o = itemsArr.getJSONObject(i)
            val unit = o.getString("unit")
            require(unit in validUnits) { "وحدة غير معروفة" }
            items.add(
                Item(
                    id = o.getLong("id"),
                    name = o.getString("name"),
                    unit = unit,
                    packSize = maxOf(o.getInt("packSize"), 1),
                    quantity = o.getDouble("quantity"),
                    minQuantity = o.getDouble("minQuantity"),
                )
            )
        }

        val moves = ArrayList<Movement>()
        val movesArr = root.getJSONArray("movements")
        for (i in 0 until movesArr.length()) {
            val o = movesArr.getJSONObject(i)
            moves.add(
                Movement(
                    id = o.getLong("id"),
                    itemId = o.getLong("itemId"),
                    itemName = o.getString("itemName"),
                    unit = o.getString("unit"),
                    packSize = maxOf(o.getInt("packSize"), 1),
                    type = o.getString("type"),
                    amount = o.getDouble("amount"),
                    balanceAfter = o.getDouble("balanceAfter"),
                    timestamp = o.getLong("timestamp"),
                    note = o.optString("note", ""),
                )
            )
        }
        return Pair(items, moves)
    }
}
