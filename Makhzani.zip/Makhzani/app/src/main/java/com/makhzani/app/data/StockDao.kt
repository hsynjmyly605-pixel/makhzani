package com.makhzani.app.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface StockDao {
    @Query("SELECT * FROM items ORDER BY id ASC")
    fun observeItems(): Flow<List<Item>>

    @Query("SELECT * FROM movements ORDER BY timestamp DESC, id DESC")
    fun observeMovements(): Flow<List<Movement>>

    @Query("SELECT * FROM items ORDER BY id ASC")
    suspend fun getItems(): List<Item>

    @Query("SELECT * FROM movements ORDER BY id ASC")
    suspend fun getMovements(): List<Movement>

    @Query("SELECT * FROM items WHERE id = :id")
    suspend fun getItem(id: Long): Item?

    @Insert
    suspend fun insertItem(item: Item): Long

    @Insert
    suspend fun insertItems(items: List<Item>)

    @Insert
    suspend fun insertMovement(movement: Movement)

    @Insert
    suspend fun insertMovements(movements: List<Movement>)

    @Update
    suspend fun updateItem(item: Item)

    @Query("UPDATE movements SET itemName = :name WHERE itemId = :id")
    suspend fun renameInMovements(id: Long, name: String)

    @Query("DELETE FROM items WHERE id = :id")
    suspend fun deleteItem(id: Long)

    @Query("DELETE FROM items")
    suspend fun clearItems()

    @Query("DELETE FROM movements")
    suspend fun clearMovements()
}
