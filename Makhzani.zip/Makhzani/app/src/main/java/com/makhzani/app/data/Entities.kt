package com.makhzani.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

object Units {
    const val KG = "KG"
    const val PIECE = "PIECE"
    const val PACK = "PACK"
}

object MoveType {
    const val IN = "IN"
    const val OUT = "OUT"
}

/**
 * quantity و minQuantity تُخزَّن دائماً بالوحدة الأساسية:
 *  - الكيلوغرام للمواد بالكيلو
 *  - القطعة للمواد بالقطعة
 *  - القطعة أيضاً للمواد بالطرد (الطرد = packSize قطعة)
 */
@Entity(tableName = "items")
data class Item(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val unit: String,
    val packSize: Int = 1,
    val quantity: Double = 0.0,
    val minQuantity: Double = 0.0,
)

@Entity(tableName = "movements")
data class Movement(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val itemId: Long,
    val itemName: String,
    val unit: String,
    val packSize: Int,
    val type: String,
    val amount: Double,
    val balanceAfter: Double,
    val timestamp: Long,
    val note: String = "",
)

fun round3(v: Double): Double = Math.round(v * 1000.0) / 1000.0
