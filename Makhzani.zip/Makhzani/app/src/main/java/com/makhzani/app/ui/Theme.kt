package com.makhzani.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val GreenPrimary = Color(0xFF2E7D32)
val GreenDark = Color(0xFF1B5E20)
val GreenLight = Color(0xFFE8F5E9)
val GreenMid = Color(0xFFC8E6C9)
val ScreenBg = Color(0xFFF6FAF6)

private val Colors = lightColorScheme(
    primary = GreenPrimary,
    onPrimary = Color.White,
    primaryContainer = GreenLight,
    onPrimaryContainer = GreenDark,
    secondary = Color(0xFF66BB6A),
    onSecondary = Color.White,
    background = Color.White,
    onBackground = Color(0xFF1B1B1B),
    surface = Color.White,
    onSurface = Color(0xFF1B1B1B),
    surfaceVariant = GreenLight,
    onSurfaceVariant = Color(0xFF3C4A3D),
    error = Color(0xFFC62828),
    onError = Color.White,
)

@Composable
fun MakhzaniTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Colors, content = content)
}
