package com.makhzani.app

import com.makhzani.app.data.Item
import com.makhzani.app.data.Units
import com.makhzani.app.data.round3
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

fun fmtNum(v: Double): String {
    return DecimalFormat("0.###", DecimalFormatSymbols(Locale.US)).format(round3(v))
}

fun unitShort(unit: String): String = when (unit) {
    Units.KG -> "كغ"
    Units.PIECE -> "قطعة"
    else -> "طرد"
}

fun unitName(unit: String): String = when (unit) {
    Units.KG -> "كيلوغرام"
    Units.PIECE -> "قطعة"
    else -> "طرد"
}

/** يعرض كمية (بالوحدة الأساسية) بشكل مفهوم، مع تحويل الطرود تلقائياً */
fun fmtQty(unit: String, packSize: Int, base: Double): String {
    return when (unit) {
        Units.KG -> "${fmtNum(base)} كغ"
        Units.PIECE -> "${fmtNum(base)} قطعة"
        else -> {
            val size = maxOf(packSize, 1).toLong()
            val total = Math.round(base)
            val packs = total / size
            val rest = total % size
            if (rest == 0L) "$packs طرد ($total قطعة)"
            else "$packs طرد و $rest قطعة ($total قطعة)"
        }
    }
}

fun Item.qtyText(): String = fmtQty(unit, packSize, quantity)

fun Item.isLow(): Boolean = quantity <= minQuantity

fun fmtDate(ts: Long): String {
    val f = SimpleDateFormat("yyyy/MM/dd  hh:mm a", Locale.forLanguageTag("ar-u-nu-latn"))
    return f.format(Date(ts))
}

/** يقبل الأرقام العربية والفاصلة العربية */
fun parseNum(s: String): Double? {
    val sb = StringBuilder()
    for (c in s.trim()) {
        when (c) {
            in '٠'..'٩' -> sb.append('0' + (c - '٠'))
            in '۰'..'۹' -> sb.append('0' + (c - '۰'))
            '٫', ',', '،' -> sb.append('.')
            else -> sb.append(c)
        }
    }
    val d = sb.toString().toDoubleOrNull() ?: return null
    return if (d.isFinite()) d else null
}
