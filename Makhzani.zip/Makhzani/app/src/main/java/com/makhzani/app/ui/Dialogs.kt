package com.makhzani.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.makhzani.app.data.Item
import com.makhzani.app.data.MoveType
import com.makhzani.app.data.Units
import com.makhzani.app.fmtNum
import com.makhzani.app.fmtQty
import com.makhzani.app.parseNum
import com.makhzani.app.qtyText
import com.makhzani.app.unitName
import com.makhzani.app.unitShort

private val DecimalKeyboard = KeyboardOptions(keyboardType = KeyboardType.Decimal)

@Composable
fun RadioRow(selected: Boolean, label: String, onClick: () -> Unit) {
    Row(
        modifier = Modifier.clickable(onClick = onClick),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        RadioButton(selected = selected, onClick = onClick)
        Text(label)
        Spacer(Modifier.width(12.dp))
    }
}

/**
 * إضافة مادة جديدة أو تعديل مادة موجودة.
 * onSave(name, unit, packSize, qtyDisplay, minDisplay)
 * الكميات هنا "كما يراها المستخدم": بالطرد للمواد بالطرد.
 */
@Composable
fun ItemDialog(
    existing: Item?,
    onDismiss: () -> Unit,
    onSave: (String, String, Int, Double, Double) -> Unit,
) {
    val isEdit = existing != null
    var name by remember { mutableStateOf(existing?.name ?: "") }
    var unit by remember { mutableStateOf(existing?.unit ?: Units.KG) }
    var packText by remember { mutableStateOf("48") }
    var qtyText by remember { mutableStateOf("") }
    var minText by remember {
        mutableStateOf(
            if (existing != null) {
                val div = if (existing.unit == Units.PACK) existing.packSize else 1
                fmtNum(existing.minQuantity / div)
            } else ""
        )
    }
    var error by remember { mutableStateOf<String?>(null) }

    val effUnit = existing?.unit ?: unit

    fun save() {
        val n = name.trim()
        if (n.isEmpty()) {
            error = "اكتب اسم المادة"
            return
        }
        val size = when {
            existing != null -> existing.packSize
            unit == Units.PACK -> parseNum(packText)?.toInt() ?: 0
            else -> 1
        }
        if (effUnit == Units.PACK && size < 1) {
            error = "اكتب عدد القطع في الطرد الواحد"
            return
        }
        val qty = if (qtyText.isBlank()) 0.0 else parseNum(qtyText)
        val min = if (minText.isBlank()) 0.0 else parseNum(minText)
        if (!isEdit && (qty == null || qty < 0.0)) {
            error = "الكمية غير صحيحة"
            return
        }
        if (min == null || min < 0.0) {
            error = "حد التنبيه غير صحيح"
            return
        }
        if (effUnit != Units.KG) {
            val q = qty ?: 0.0
            if (q % 1.0 != 0.0 || min % 1.0 != 0.0) {
                error = "أدخل أعداداً صحيحة لهذه الوحدة"
                return
            }
        }
        onSave(n, effUnit, size, qty ?: 0.0, min)
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (isEdit) "تعديل المادة" else "إضافة مادة جديدة") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it; error = null },
                    label = { Text("اسم المادة") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                if (!isEdit) {
                    Text("وحدة القياس", fontWeight = FontWeight.Bold)
                    RadioRow(unit == Units.KG, "كيلوغرام") { unit = Units.KG }
                    RadioRow(unit == Units.PIECE, "قطعة") { unit = Units.PIECE }
                    RadioRow(unit == Units.PACK, "طرد") { unit = Units.PACK }
                    if (unit == Units.PACK) {
                        OutlinedTextField(
                            value = packText,
                            onValueChange = { packText = it; error = null },
                            label = { Text("عدد القطع في الطرد الواحد") },
                            keyboardOptions = DecimalKeyboard,
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                        )
                    }
                    OutlinedTextField(
                        value = qtyText,
                        onValueChange = { qtyText = it; error = null },
                        label = { Text("الكمية الحالية (${unitShort(effUnit)})") },
                        keyboardOptions = DecimalKeyboard,
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                    )
                } else {
                    Text("الوحدة: ${unitName(effUnit)}", fontSize = 13.sp)
                }
                OutlinedTextField(
                    value = minText,
                    onValueChange = { minText = it; error = null },
                    label = { Text("حد التنبيه (${unitShort(effUnit)})") },
                    keyboardOptions = DecimalKeyboard,
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                val e = error
                if (e != null) {
                    Text(e, color = MaterialTheme.colorScheme.error, fontSize = 13.sp)
                }
            }
        },
        confirmButton = { TextButton(onClick = { save() }) { Text("حفظ") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } },
    )
}

/**
 * إضافة أو سحب كمية.
 * onConfirm(amountBase, note): الكمية بالوحدة الأساسية (الطرد يُحوَّل تلقائياً إلى قطع).
 */
@Composable
fun MoveDialog(
    item: Item,
    type: String,
    onDismiss: () -> Unit,
    onConfirm: (Double, String) -> Unit,
) {
    val isIn = type == MoveType.IN
    val isPack = item.unit == Units.PACK
    var amountText by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var inPieces by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    val amount = parseNum(amountText)

    fun confirm() {
        if (amount == null || amount <= 0.0) {
            error = "أدخل كمية صحيحة"
            return
        }
        val base = if (isPack && !inPieces) amount * item.packSize else amount
        if (item.unit != Units.KG && base % 1.0 != 0.0) {
            error = "أدخل عدداً صحيحاً"
            return
        }
        if (!isIn && base > item.quantity + 0.0005) {
            error = "الكمية المتوفرة غير كافية"
            return
        }
        onConfirm(base, note.trim())
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text((if (isIn) "إضافة إلى " else "سحب من ") + item.name) },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Text("المتوفر حالياً: ${item.qtyText()}", fontWeight = FontWeight.Bold)
                if (isPack) {
                    Row {
                        RadioRow(!inPieces, "طرد") { inPieces = false; error = null }
                        RadioRow(inPieces, "قطعة") { inPieces = true; error = null }
                    }
                }
                val label = when {
                    isPack && inPieces -> "عدد القطع"
                    isPack -> "عدد الطرود"
                    else -> "الكمية (${unitShort(item.unit)})"
                }
                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it; error = null },
                    label = { Text(label) },
                    keyboardOptions = DecimalKeyboard,
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                if (isPack && !inPieces && amount != null && amount > 0.0) {
                    Text(
                        "= ${fmtQty(Units.PIECE, 1, amount * item.packSize)}  (الطرد الواحد ${item.packSize} قطعة)",
                        color = MaterialTheme.colorScheme.primary,
                        fontSize = 13.sp,
                    )
                }
                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it },
                    label = { Text("ملاحظة (اختياري)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                val e = error
                if (e != null) {
                    Text(e, color = MaterialTheme.colorScheme.error, fontSize = 13.sp)
                }
            }
        },
        confirmButton = { TextButton(onClick = { confirm() }) { Text(if (isIn) "إضافة" else "سحب") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } },
    )
}
